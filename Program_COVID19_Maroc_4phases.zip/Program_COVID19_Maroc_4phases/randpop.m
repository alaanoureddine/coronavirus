function pop=randpop(N,d,a,b)
  pop=a+(b-a)*rand(d,N);
end

